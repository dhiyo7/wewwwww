package crud.id.plugin.utsdhiyokuis;

import com.google.gson.annotations.SerializedName;

class Mahasiswa {
    @SerializedName("id")
    private String id;
    @SerializedName("nim")
    private String nim;
    @SerializedName("nama")
    private String nama;
    @SerializedName("hp")
    private String hp;
    @SerializedName("keterangan")
    private String keterangan;

    public String getId() {
        return id;
    }

    public String getNim() {
        return nim;
    }

    public String getNama() {
        return nama;
    }

    public String getHp() {
        return hp;
    }

    public String getKeterangan() {
        return keterangan;
    }
}
