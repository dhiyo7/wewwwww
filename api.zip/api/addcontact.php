<?php 

require_once 'connection.php';

if ( $_SERVER['REQUEST_METHOD'] == 'POST' ){

    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $hp = $_POST['hp'];
    $keterangan = $_POST['keterangan'];

    if ( $nim == '' || $name == '' || $alamat == '' || $hp == '' || $keterangan == '' ){

        echo 'Mohon isi semua data!';

    } else {

        $query = "INSERT INTO mahasiswa (nim,nama,alamat,hp,keterangan) VALUES ('$nim', '$nama', '$alamat', '$hp', $keterangan)";

        if ( mysqli_query($conn, $query) ){
            $response["value"] = 1;
            $response["message"] = $name." Sukses ditambahkan";
            echo json_encode($response);
        } else {
            $response["value"] = 0;
            $response["message"] = "Oops! ".$name." Gagal ditambahkan, \n Silahkan Coba lagi!";
            echo json_encode($response);
        }
    }

    mysqli_close($conn);

} else {
    $response["value"] = 0;
    $response["message"] = "oops! Coba lagi!";
    echo json_encode($response);
}

?>