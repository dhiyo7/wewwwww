<?php 

require_once 'connection.php';

$query = mysqli_query($conn, "SELECT * FROM mahasiswa ORDER BY id DESC");

$array = array();

while ($row = mysqli_fetch_assoc($query)) {
    array_push($array, array(
        'id' => $row['id'], 
        'nim' => $row['nim'],
        'nama' => $row['nama'],
        'alamat' => $row['alamat'], 
        'hp' => $row['hp'],
        'keterangan' => $row['keterangan'], ));
}

echo json_encode($array);

?>